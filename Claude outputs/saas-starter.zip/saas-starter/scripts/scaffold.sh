#!/usr/bin/env bash
# Creates the default-stack skeleton, laid out like Asset-Management-App:
#   <Product>.API  <Product>.Application  <Product>.Domain  <Product>.Infrastructure   (repo root)
#   <Product>.UnitTests  <Product>.IntegrationTests  <Product>.AcceptanceTests       (repo root)
#   web/  (React + TypeScript)
#   ./scripts/scaffold.sh InvoiceManager
# The platform code itself (auth, tenancy, filters, BaseResponse, ...) is task T001, built by Claude
# following docs/stack/dotnet-react.md and verified by the acceptance tests.
# Env: OFFLINE=1 skips all downloads; NUGET_OFFLINE=1 skips only NuGet (used to test the kit itself).
# Portable: bash 3.2 (macOS) and GNU/BSD tools.
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
OFFLINE="${OFFLINE:-0}"
NUGET_OFFLINE="${NUGET_OFFLINE:-$OFFLINE}"
NR=(); [[ "$NUGET_OFFLINE" == "1" ]] && NR=(--no-restore)

P="${1:-}"
NAME_RE='^[A-Z][A-Za-z0-9]{2,40}$'
if ! [[ "$P" =~ $NAME_RE ]]; then
  echo "usage: ./scripts/scaffold.sh <ProductName>   (PascalCase, e.g. InvoiceManager)"; exit 1
fi
shopt -s nullglob; existing_sln=(./*.slnx ./*.sln); shopt -u nullglob
if (( ${#existing_sln[@]} )); then
  if grep -qE '^PRODUCT="[A-Za-z0-9]+"' .factory/factory.conf; then
    echo "Already scaffolded. Nothing to do."; exit 0
  fi
  echo "A previous scaffold stopped half-way (solution exists, PRODUCT not set)."
  echo "Remove the generated <Name>.* folders, *.slnx and web/, then run this again."; exit 1
fi
command -v dotnet >/dev/null || { echo "dotnet SDK 10 is required"; exit 1; }
command -v npm >/dev/null || { echo "Node.js 22+ is required"; exit 1; }
command -v perl >/dev/null || { echo "perl is required"; exit 1; }

conf_set() { KEY="$1" VAL="$2" perl -pi -e 's/^\Q$ENV{KEY}\E=.*/$ENV{KEY}="$ENV{VAL}"/' .factory/factory.conf; }

# Insert an ItemGroup into a csproj (portable alternative to GNU sed -i with newlines).
csproj_insert() { # project-dir xml-lines
  local csproj; csproj="$(ls "$1"/*.csproj)"
  XML="$2" perl -0pi -e 's#</Project>#  <ItemGroup>\n$ENV{XML}\n  </ItemGroup>\n\n</Project>#' "$csproj"
}
# Versions float within the major so a future major release cannot break the scaffold.
pkg() { csproj_insert "$1" "    <PackageReference Include=\"$2\" Version=\"$3\" />"; }
# Replace __PRODUCT__ in generated files.
product_subst() { PRODUCT="$P" perl -pi -e 's/__PRODUCT__/$ENV{PRODUCT}/g' "$@"; }

echo "== backend ($P)"
dotnet new sln -n "$P"
for layer in Domain Application Infrastructure; do
  dotnet new classlib -n "$P.$layer" -o "$P.$layer" ${NR[@]+"${NR[@]}"}
  rm -f "$P.$layer/Class1.cs"
done
dotnet new webapi -n "$P.API" -o "$P.API" --use-controllers ${NR[@]+"${NR[@]}"}
rm -f "$P.API/$P.API.http" "$P.API/WeatherForecast.cs" "$P.API/Controllers/WeatherForecastController.cs"
dotnet user-secrets init --project "$P.API" >/dev/null
for t in UnitTests IntegrationTests AcceptanceTests; do
  dotnet new xunit -n "$P.$t" -o "$P.$t" ${NR[@]+"${NR[@]}"}
  rm -f "$P.$t/UnitTest1.cs"
done
csproj_insert "$P.Application" '    <FrameworkReference Include="Microsoft.AspNetCore.App" />'
csproj_insert "$P.Infrastructure" '    <FrameworkReference Include="Microsoft.AspNetCore.App" />'

dotnet sln "$P.slnx" add "$P.API" "$P.Application" "$P.Domain" "$P.Infrastructure" \
  "$P.UnitTests" "$P.IntegrationTests" "$P.AcceptanceTests"

# Dependency rule: Application -> Domain, Infrastructure -> Domain, API -> Application + Infrastructure.
dotnet add "$P.Application" reference "$P.Domain"
dotnet add "$P.Infrastructure" reference "$P.Domain"
dotnet add "$P.API" reference "$P.Application" "$P.Infrastructure"
dotnet add "$P.UnitTests" reference "$P.Domain" "$P.Application" "$P.Infrastructure" "$P.API"
dotnet add "$P.IntegrationTests" reference "$P.API" "$P.Infrastructure"
dotnet add "$P.AcceptanceTests" reference "$P.API"

pkg "$P.Domain" ErrorOr "2.*"
pkg "$P.Domain" Microsoft.Extensions.Identity.Stores "10.0.*"
pkg "$P.Application" FluentValidation.DependencyInjectionExtensions "12.*"
pkg "$P.Application" Polly "8.*"
pkg "$P.Infrastructure" Microsoft.EntityFrameworkCore.SqlServer "10.0.*"
pkg "$P.Infrastructure" Microsoft.EntityFrameworkCore.Design "10.0.*"
pkg "$P.Infrastructure" Microsoft.AspNetCore.Identity.EntityFrameworkCore "10.0.*"
pkg "$P.Infrastructure" Microsoft.AspNetCore.Authentication.JwtBearer "10.0.*"
pkg "$P.Infrastructure" Microsoft.Extensions.Caching.StackExchangeRedis "10.0.*"
pkg "$P.Infrastructure" Microsoft.Extensions.Diagnostics.HealthChecks.EntityFrameworkCore "10.0.*"
pkg "$P.Infrastructure" Dapper "2.*"
for t in IntegrationTests AcceptanceTests; do
  pkg "$P.$t" Microsoft.AspNetCore.Mvc.Testing "10.0.*"
  pkg "$P.$t" Testcontainers.MsSql "4.*"
done

mkdir -p "$P.Domain/Interfaces"
cat >"$P.Domain/Interfaces/IEmailSender.cs" <<'CS'
namespace __PRODUCT__.Domain.Interfaces;

/// <summary>Outgoing email. Development uses a logging sender; production plugs in a real provider.</summary>
public interface IEmailSender
{
    Task SendAsync(string to, string subject, string body, CancellationToken cancellationToken = default);
}
CS

cat >"$P.API/Program.cs" <<'CS'
var builder = WebApplication.CreateBuilder(args);

builder.Services.AddOpenApi();

builder.Services.AddControllers()
    // Enums travel as names, not numbers: { "status": "Active" }.
    .AddJsonOptions(options =>
        options.JsonSerializerOptions.Converters.Add(
            new System.Text.Json.Serialization.JsonStringEnumConverter()));

// Platform baseline (task T001): AddApplication / AddInfrastructure, ValidationFilter, ExceptionFilter,
// Identity + JWT, tenancy, rate limiting, security headers, /health and SPA hosting —
// following docs/stack/dotnet-react.md.

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.MapOpenApi();
}

app.MapControllers();

app.Run();

public partial class Program { }
CS

# One factory per test project. The acceptance copy is LOCKED with the tests after approval, so the
# implementation cannot change how the acceptance suite boots the app. The integration copy is yours.
write_factory() { # namespace target-file
  cat >"$2" <<'CS'
using __PRODUCT__.Domain.Interfaces;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.AspNetCore.TestHost;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Testcontainers.MsSql;

namespace __NAMESPACE__;

/// <summary>
/// Boots the real API (environment "Testing") against a real SQL Server:
/// a Testcontainers instance, or TEST_DB_CONNECTION when set.
/// Outgoing email is captured in <see cref="Emails"/> so tests can read confirmation/reset tokens.
/// </summary>
public sealed class AppFactory : WebApplicationFactory<Program>, IAsyncLifetime
{
    private readonly string? _external = Environment.GetEnvironmentVariable("TEST_DB_CONNECTION");
    private MsSqlContainer? _db;

    // Test-only HS256 signing key, generated per run: 128 hex characters (design.md §8: at least 64).
    private readonly string _jwtKey = string.Concat(Enumerable.Range(0, 4).Select(_ => Guid.NewGuid().ToString("N")));

    public CapturingEmailSender Emails { get; } = new();

    public string ConnectionString => _external ?? _db?.GetConnectionString()
        ?? throw new InvalidOperationException("Database not started.");

    public async Task InitializeAsync()
    {
        if (string.IsNullOrEmpty(_external))
        {
            _db = new MsSqlBuilder("mcr.microsoft.com/mssql/server:2022-latest").Build();
            await _db.StartAsync();
        }
        // Read by Program.cs during startup (before WebApplicationFactory overrides apply).
        Environment.SetEnvironmentVariable("ConnectionStrings__DefaultConnection", ConnectionString);
        Environment.SetEnvironmentVariable("JwtSettings__Key", _jwtKey);
    }

    protected override void ConfigureWebHost(IWebHostBuilder builder)
    {
        builder.UseEnvironment("Testing");
        builder.UseSetting("ConnectionStrings:DefaultConnection", ConnectionString);
        builder.UseSetting("JwtSettings:Key", _jwtKey);
        builder.ConfigureTestServices(services =>
        {
            services.RemoveAll<IEmailSender>();
            services.AddSingleton<IEmailSender>(Emails);
            // Test-only endpoints (TestEndpointsController in this assembly), e.g. GET /api/_test/throw.
            services.AddControllers().AddApplicationPart(typeof(AppFactory).Assembly);
        });
    }

    async Task IAsyncLifetime.DisposeAsync()
    {
        await base.DisposeAsync();
        if (_db is not null) await _db.DisposeAsync();
    }
}
CS
  NS="$1" perl -pi -e 's/__NAMESPACE__/$ENV{NS}/' "$2"
}
write_factory "$P.AcceptanceTests" "$P.AcceptanceTests/AppFactory.cs"
write_factory "$P.IntegrationTests" "$P.IntegrationTests/AppFactory.cs"

write_email_capture() { # namespace target-file
  cat >"$2" <<'CS'
using System.Collections.Concurrent;
using __PRODUCT__.Domain.Interfaces;

namespace __NAMESPACE__;

public sealed record SentEmail(string To, string Subject, string Body);

/// <summary>Replaces the real email sender in tests; every message is kept in memory.</summary>
public sealed class CapturingEmailSender : IEmailSender
{
    private readonly ConcurrentQueue<SentEmail> _sent = new();

    public IReadOnlyList<SentEmail> Sent => _sent.ToArray();

    public SentEmail? LastTo(string email) =>
        _sent.Reverse().FirstOrDefault(e => string.Equals(e.To, email, StringComparison.OrdinalIgnoreCase));

    public Task SendAsync(string to, string subject, string body, CancellationToken cancellationToken = default)
    {
        _sent.Enqueue(new SentEmail(to, subject, body));
        return Task.CompletedTask;
    }
}
CS
  NS="$1" perl -pi -e 's/__NAMESPACE__/$ENV{NS}/' "$2"
}
write_email_capture "$P.AcceptanceTests" "$P.AcceptanceTests/CapturingEmailSender.cs"
write_email_capture "$P.IntegrationTests" "$P.IntegrationTests/CapturingEmailSender.cs"

write_test_endpoints() { # namespace target-file
  cat >"$2" <<'CS'
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace __NAMESPACE__;

/// <summary>
/// Exists only inside the test host (added by AppFactory). Lets black-box tests trigger an unhandled error
/// (REQ-P09) without knowing the implementation. Documented in docs/design.md §5.
/// </summary>
[AllowAnonymous]
[Route("api/_test")]
public sealed class TestEndpointsController : ControllerBase
{
    public const string SecretDetail = "test-internal-detail-7f3a";

    [HttpGet("throw")]
    public IActionResult Throw() => throw new InvalidOperationException(SecretDetail);
}
CS
  NS="$1" perl -pi -e 's/__NAMESPACE__/$ENV{NS}/' "$2"
}
write_test_endpoints "$P.AcceptanceTests" "$P.AcceptanceTests/TestEndpointsController.cs"
write_test_endpoints "$P.IntegrationTests" "$P.IntegrationTests/TestEndpointsController.cs"

cat >"$P.AcceptanceTests/AcceptanceCollection.cs" <<'CS'
namespace __PRODUCT__.AcceptanceTests;

/// <summary>All acceptance tests share one running API + database. Use [Collection(AcceptanceCollection.Name)].</summary>
[CollectionDefinition(Name)]
public sealed class AcceptanceCollection : ICollectionFixture<AppFactory>
{
    public const string Name = "acceptance";
}
CS

cat >"$P.IntegrationTests/IntegrationCollection.cs" <<'CS'
namespace __PRODUCT__.IntegrationTests;

[CollectionDefinition(Name)]
public sealed class IntegrationCollection : ICollectionFixture<AppFactory>
{
    public const string Name = "integration";
}
CS

cat >"$P.UnitTests/ArchitectureTests.cs" <<'CS'
using System.Reflection;

namespace __PRODUCT__.UnitTests;

/// <summary>Enforces the dependency rule: Domain ← Application, Domain ← Infrastructure, API → both.</summary>
public class ArchitectureTests
{
    private const string Product = "__PRODUCT__";

    private static string[] ProductReferences(string layer) =>
        Assembly.Load($"{Product}.{layer}").GetReferencedAssemblies()
            .Select(a => a.Name!)
            .Where(n => n.StartsWith(Product + ".", StringComparison.Ordinal))
            .ToArray();

    [Fact]
    public void Domain_depends_on_no_other_layer() =>
        Assert.Empty(ProductReferences("Domain"));

    [Fact]
    public void Application_depends_only_on_Domain() =>
        Assert.All(ProductReferences("Application"), n => Assert.Equal($"{Product}.Domain", n));

    [Fact]
    public void Infrastructure_depends_only_on_Domain() =>
        Assert.All(ProductReferences("Infrastructure"), n => Assert.Equal($"{Product}.Domain", n));
}
CS

product_subst "$P.Domain/Interfaces/IEmailSender.cs" "$P.AcceptanceTests/"*.cs "$P.IntegrationTests/"*.cs \
  "$P.UnitTests/ArchitectureTests.cs" Dockerfile docker-compose.yml

if [[ "$NUGET_OFFLINE" != "1" ]]; then
  dotnet new tool-manifest --force
  dotnet tool install dotnet-ef --version "10.0.*"
  dotnet restore "$P.slnx"
fi

echo "== frontend"
npm create vite@9 web -- --template react-ts --no-interactive </dev/null
cd web
rm -f README.md src/App.css
rm -rf src/assets public/vite.svg
if [[ "$OFFLINE" != "1" ]]; then
  npm install
  npm install @tanstack/react-query react-router
  npm install -D vitest jsdom @testing-library/react @testing-library/jest-dom @testing-library/user-event \
    @playwright/test prettier tailwindcss @tailwindcss/vite
  npx playwright install chromium || echo "WARNING: Playwright browser download failed; run 'cd web && npx playwright install chromium' later."
fi
npm pkg set scripts.typecheck="tsc -b" scripts.test="vitest run" scripts.e2e="playwright test" \
  scripts.e2e:acceptance="playwright test -c e2e/acceptance/playwright.config.ts" \
  scripts.format="prettier --write ."

cat >vite.config.ts <<'TS'
/// <reference types="vitest/config" />
import tailwindcss from '@tailwindcss/vite'
import react from '@vitejs/plugin-react'
import { defineConfig } from 'vite'

// The API runs on :5080 in development; the browser only talks to the Vite origin.
export default defineConfig({
  plugins: [react(), tailwindcss()],
  server: {
    port: 5173,
    proxy: { '/api': 'http://localhost:5080', '/health': 'http://localhost:5080' },
  },
  test: {
    environment: 'jsdom',
    setupFiles: ['./src/test/setup.ts'],
    include: ['src/**/*.test.{ts,tsx}'],
  },
})
TS

# Dev servers for both Playwright configs. Kept in the locked acceptance folder so the implementation
# cannot change what the acceptance suite talks to.
mkdir -p src/test e2e/acceptance e2e/flows
cat >e2e/acceptance/servers.ts <<'TS'
// Always run Playwright from web/ (npm scripts and scripts/verify.sh do).
const webDir = process.cwd()
const db =
  process.env.TEST_DB_CONNECTION ??
  'Server=localhost,1433;Database=__PRODUCT__E2E;User Id=sa;Password=Local_Dev_Passw0rd!;TrustServerCertificate=True'

export const webServer = [
  {
    command: 'dotnet run --project ../__PRODUCT__.API --urls http://localhost:5080',
    cwd: webDir,
    url: 'http://localhost:5080/health',
    timeout: 180_000,
    reuseExistingServer: !process.env.CI,
    env: {
      ASPNETCORE_ENVIRONMENT: 'Development',
      ConnectionStrings__DefaultConnection: db,
      // Local E2E only; real keys come from user-secrets / environment variables.
      JwtSettings__Key: '0123456789abcdef'.repeat(8), // 128 chars, local E2E only (design.md §8)
    },
  },
  {
    command: 'npm run dev',
    cwd: webDir,
    url: 'http://localhost:5173',
    timeout: 60_000,
    reuseExistingServer: !process.env.CI,
  },
]
TS
PRODUCT="$P" perl -pi -e 's/__PRODUCT__/$ENV{PRODUCT}/g' e2e/acceptance/servers.ts

# Acceptance config lives INSIDE the locked folder: the implementation cannot change which
# acceptance tests run or on which devices.
cat >e2e/acceptance/playwright.config.ts <<'TS'
import { defineConfig, devices } from '@playwright/test'
import { webServer } from './servers'

export default defineConfig({
  testDir: '.',
  fullyParallel: false,
  forbidOnly: true,
  retries: process.env.CI ? 1 : 0,
  reporter: [['list']],
  use: { baseURL: 'http://localhost:5173', trace: 'retain-on-failure', screenshot: 'only-on-failure' },
  projects: [
    { name: 'desktop', use: { ...devices['Desktop Chrome'] } },
    { name: 'mobile', use: { ...devices['Pixel 7'] } },
  ],
  webServer,
})
TS

# Your own browser flows / regression tests (not locked).
cat >playwright.config.ts <<'TS'
import { defineConfig, devices } from '@playwright/test'
import { webServer } from './e2e/acceptance/servers'

export default defineConfig({
  testDir: './e2e/flows',
  fullyParallel: false,
  forbidOnly: !!process.env.CI,
  retries: process.env.CI ? 1 : 0,
  reporter: [['list'], ['html', { open: 'never' }]],
  use: { baseURL: 'http://localhost:5173', trace: 'retain-on-failure', screenshot: 'only-on-failure' },
  projects: [{ name: 'flows', use: { ...devices['Desktop Chrome'] } }],
  webServer,
})
TS

cat >src/test/setup.ts <<'TS'
import '@testing-library/jest-dom/vitest'
TS
cat >src/index.css <<'CSS'
@import 'tailwindcss';
CSS
cat >src/App.tsx <<'TSX'
// Placeholder shell. The product UI is built in the build loop following docs/design.md.
export default function App() {
  return (
    <main className="mx-auto max-w-3xl p-6">
      <h1 className="text-2xl font-semibold">App</h1>
    </main>
  )
}
TSX
cat >src/App.test.tsx <<'TSX'
import { render, screen } from '@testing-library/react'
import { describe, expect, it } from 'vitest'
import App from './App'

describe('App', () => {
  it('renders the shell', () => {
    render(<App />)
    expect(screen.getByRole('heading', { level: 1 })).toBeInTheDocument()
  })
})
TSX
touch e2e/flows/.gitkeep
cat >.prettierignore <<'TXT'
dist
node_modules
playwright-report
test-results
e2e/acceptance
TXT
cat >.prettierrc.json <<'JSON'
{ "semi": false, "singleQuote": true, "printWidth": 100 }
JSON
if [[ "$OFFLINE" != "1" ]]; then npx prettier --write . >/dev/null; fi
cd "$ROOT"

# Record the product last, so a half-finished scaffold is detectable.
conf_set LOCKED_PATHS "docs/requirements.md $P.AcceptanceTests/ web/e2e/acceptance/"
conf_set IMPLEMENTATION_PATHS "$P.API/ $P.Application/ $P.Domain/ $P.Infrastructure/ web/src/"
conf_set PRODUCT "$P"

git add -A
git commit -q -m "chore: scaffold $P (default stack)" || true
echo
echo "Scaffold of $P done. Next: ./scripts/verify.sh --quick (expect failures until requirements and tests exist)."
