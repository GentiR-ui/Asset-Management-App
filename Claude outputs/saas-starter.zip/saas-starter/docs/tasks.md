# Tasks

> ORDER of work. Vertical slices: each task delivers working behaviour end to end (API + UI + tests),
> closes in one commit, and stays under ~400 changed lines. Split anything bigger.
> Format: `- [ ] T### — title — REQs — Definition of Done`. Check the box only when its DoD holds.

## Platform (Asset-Management style, docs/stack §2–§9)

- [ ] T001 — Core: BaseResponse + ApiControllerBase + ValidationFilter/ExceptionFilter, `AddApplication`/`AddInfrastructure`, BaseEntity + ITenantOwned + ITenantContext, ApplicationDbContext with tenant filter and audit fields, Tenant + User + AppRoles, initial migration + seed, `/health`, security headers, CacheService — REQ-P07, P08, P09 — DoD: acceptance tests for these REQs green; integration test that every ITenantOwned entity is filtered; `verify.sh --quick` green
- [ ] T002 — Auth: Identity + JWT (tenant_id + security_stamp claims, stamp check), register (creates tenant + Owner), login with generic 401 and per (IP, email) rate limit, logout, `GET /api/account/me` — REQ-P01, P02, P03, P05, P06, P11 — DoD: acceptance tests green; security-reviewer has no HIGH/MEDIUM
- [ ] T003 — Password reset + Owner user management (`/api/users`) — REQ-P12, P13, P14, P04 for users — DoD: acceptance tests green; security-reviewer has no HIGH/MEDIUM
- [ ] T004 — Web shell: api client (Bearer + BaseResponse unwrapping), router, TanStack Query, register/login/home/logout screens per design.md §6, responsive layout — REQ-P10, P11 — DoD: Playwright acceptance for P10/P11 green on desktop and mobile

## Product

<!--
- [ ] T010 — Create and list invoices (API + list page + create form) — REQ-001, REQ-002 — DoD: acceptance tests green; cross-tenant test for the new endpoints (REQ-P04) green; security-reviewer has no HIGH/MEDIUM
- [ ] T011 — Send invoice — REQ-003 — DoD: ...
-->

<FILL: product slices T010, T011, ...>

## Release

- [ ] T090 — Full hardening pass over the whole app (harden skill) — DoD: security-reviewer report has no HIGH/MEDIUM
- [ ] T091 — Final QA (release skill): qa subagent explores every flow on desktop + mobile; RELEASE.md written — DoD: `scripts/verify.sh` full PASS
