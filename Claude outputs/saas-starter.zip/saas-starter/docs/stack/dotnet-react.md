# Default stack conventions — the Asset-Management-App standard

Every product follows the structure and patterns of Asset-Management-App (ASP.NET Core 10 controllers,
Clean layers, ErrorOr, BaseResponse, FluentValidation, EF Core + SQL Server, Identity + JWT, Redis cache),
plus the improvements marked **[new]**: tests, structural tenancy, constructor-only DI, a single error
mechanism, rate limiting and security headers. Read this before writing code; the reviewer checks against it.
Snippets are patterns, not files to paste blindly — keep them compiling and tested.

## 1. Layout (`<P>` = product name from `.factory/factory.conf`)

```
<P>.slnx
<P>.Domain/          Common/ (BaseEntity, AppRoles, ITenantOwned), Entities/, Enums/, Errors/,
                     Interfaces/ (repositories, ICacheService, IEmailSender, ITenantContext, ...), ReadModels/
<P>.Application/     Services/, Interfaces/ (I<Feature>Service), DTOs/<Feature>/, Validators/,
                     Common/Mappings/, Common/Responses/BaseResponse.cs, DependencyInjection/
<P>.Infrastructure/  ApplicationDbContext.cs, Configurations/, Migrations/, Repositories/, Identity/,
                     Email/, TransactionRunner.cs, DependencyInjection/
<P>.API/             Controllers/ (ApiControllerBase + one per feature), Filters/, Middleware/, Program.cs
<P>.UnitTests/       domain rules, services with fakes, ArchitectureTests             (yours)
<P>.IntegrationTests/ real API + SQL Server via its own AppFactory                   (yours)
<P>.AcceptanceTests/ black-box HTTP tests per REQ + AppFactory, by test-author       (LOCKED)
web/src/features/<feature>/   pages, components, api hooks, *.test.tsx              (yours)
web/e2e/acceptance/  Playwright tests per REQ + playwright.config.ts + servers.ts     (LOCKED)
web/e2e/flows/       extra browser flows / regression                                (yours)
```

**[new] Dependency rule** (enforced by `ArchitectureTests`): Application → Domain, Infrastructure → Domain,
API → Application + Infrastructure. Asset-Management had Application → Infrastructure; that coupling is gone.

## 2. Program.cs

```csharp
var builder = WebApplication.CreateBuilder(args);

builder.Services.AddOpenApi();
builder.Services.AddControllers(options =>
{
    options.Filters.Add<ValidationFilter>();
    options.Filters.Add<ExceptionFilter>();
})
.AddJsonOptions(o => o.JsonSerializerOptions.Converters.Add(new JsonStringEnumConverter()));

builder.Services.AddApplication(builder.Configuration);
builder.Services.AddInfrastructure(builder.Configuration);   // DbContext, Identity, JWT, repositories, cache, health, login limiter (§8)

var app = builder.Build();

app.UseExceptionHandler(e => e.Run(WriteGenericError));      // [new] 500 BaseResponse for errors outside MVC (REQ-P09)
app.UseSecurityHeaders();                                    // [new] REQ-P08
if (app.Environment.IsDevelopment()) app.MapOpenApi();
if (app.Environment.IsDevelopment() || app.Environment.IsEnvironment("Testing"))
    await app.MigrateAndSeedAsync();                         // migrations + seed (roles, dev data)
app.UseDefaultFiles(); app.UseStaticFiles();                 // SPA from wwwroot in the Docker image
app.UseAuthentication();
app.UseAuthorization();
app.MapHealthChecks("/health").AllowAnonymous();
app.MapControllers();
app.MapFallback("/api/{**rest}", () => Results.Json(        // unknown /api routes: 404 BaseResponse, never index.html
    new BaseResponse { Success = false, StatusCode = 404, Message = "Not found." }, statusCode: 404));
app.MapFallbackToFile("index.html").AllowAnonymous();        // SPA routes
app.Run();

public partial class Program { }
```

`WriteGenericError(HttpContext)` logs the exception and writes `BaseResponse { Success = false, StatusCode = 500,
Message = "An unexpected error occurred." }` with status 500.
Behind a reverse proxy in production add `UseForwardedHeaders` (X-Forwarded-For/Proto) first.
`app.UseHttpsRedirection()` only when the app terminates TLS itself.

## 3. Responses, controllers, errors

Keep Asset-Management's `BaseResponse` / `BaseResponse<T>` and `ApiControllerBase` (`Success`, `HandleResult`,
`Problem` mapping `ErrorType` → status code), adding one helper `TooManyRequests(message)` (429). Controllers stay thin:

```csharp
[Authorize(Roles = $"{AppRoles.Owner},{AppRoles.Member}")]
[Route("api/invoices")]
public sealed class InvoicesController(IInvoiceService invoiceService) : ApiControllerBase
{
    [HttpPost]
    public async Task<IActionResult> Create(CreateInvoiceRequest request, CancellationToken ct) =>
        HandleResult(await invoiceService.CreateAsync(request, ct), StatusCodes.Status201Created);

    [HttpGet]
    public async Task<IActionResult> GetAll([FromQuery] PageQueryRequest request, CancellationToken ct) =>
        Success(await invoiceService.GetPagedAsync(request, ct));
}
```

- Every controller or action declares its roles (or `[AllowAnonymous]` with a comment why). The
  `FallbackPolicy` (authenticated user) stays as the safety net.
- **[new] One error mechanism:** services return `ErrorOr<T>` with errors from `Domain/Errors/<Entity>Errors.cs`.
  No `NotFoundException`/`ConflictException`-style classes. `ExceptionFilter` only handles the unexpected:
  log it and return 500 with `"An unexpected error occurred."` — the exception text only in Development.
- `ValidationFilter` + FluentValidation exactly as in Asset-Management (400 with `errors` per property).
- **[new] Every error is a `BaseResponse`:** `ApiBehaviorOptions.InvalidModelStateResponseFactory` returns a
  `BaseResponse` 400 (malformed JSON, wrong types); JwtBearer `OnChallenge` / `OnForbidden` write a `BaseResponse`
  401 / 403 (call `context.HandleResponse()` in OnChallenge). Only `/health` answers plain text.
- Lists: `PageQueryRequest` (page 1.., pageSize 1–100 via validator) → `PagedResponse<T>`.

## 4. Services (Application)

```csharp
public sealed class InvoiceService(
    IInvoiceRepository invoices,
    ICustomerRepository customers,
    ICacheService cache,                     // [new] constructor injection ONLY
    TimeProvider clock) : IInvoiceService
{
    public async Task<ErrorOr<InvoiceResponse>> CreateAsync(CreateInvoiceRequest request, CancellationToken ct)
    {
        var customer = await customers.GetByIdAsync(request.CustomerId, ct);   // tenant-filtered automatically
        if (customer is null) return CustomerErrors.NotFound(request.CustomerId);

        var invoice = new Invoice { CustomerId = customer.Id, DueDate = request.DueDate, /* ... */ };
        await invoices.AddAsync(invoice, ct);
        await cache.InvalidateDashboardAsync(ct);
        return invoice.ToInvoiceResponse();
    }
}
```

- **Never** pass services as optional method parameters (`ICacheService cache = default!`) — in
  Asset-Management that made every write return 500 after saving. The reviewer treats it as HIGH.
- Mappings stay as extension methods (`ToXResponse()`); enums mapped with `.ToString()`.
- Multi-step writes go through `ITransactionRunner.ExecuteAsync(...)` (Asset-Management pattern).
- Time comes from `TimeProvider` (testable), never `DateTime.UtcNow` inside services.

## 5. Domain

```csharp
public abstract class BaseEntity
{
    public Guid Id { get; protected set; } = Guid.NewGuid();
    public DateTime CreatedAt { get; protected set; }
    public DateTime? UpdatedAt { get; protected set; }
    public Guid? UpdatedBy { get; protected set; }
}

public interface ITenantOwned { Guid TenantId { get; set; } }   // [new]
public interface ITenantContext { Guid TenantId { get; } }       // implemented in API/Infrastructure from the JWT

public static class AppRoles
{
    public const string Owner = "Owner";
    public const string Member = "Member";
    public static readonly string[] All = [Owner, Member];
}
```

Errors follow Asset-Management: `public static Error NotFound(Guid id) => Error.NotFound("Invoice.NotFound", ...)`.

## 6. Infrastructure

**[new] Tenancy is structural.** Asset-Management checked `scope.DepartmentId` by hand in each service
method, and three write paths forgot it. Here the DbContext does it for every query:

```csharp
public class ApplicationDbContext(DbContextOptions<ApplicationDbContext> options, ITenantContext tenant)
    : IdentityDbContext<User, UserRole, Guid>(options)
{
    private Guid CurrentTenantId => tenant.TenantId;   // EF parameterizes context members per query

    protected override void OnModelCreating(ModelBuilder builder)
    {
        base.OnModelCreating(builder);
        builder.Entity<User>(b => b.ToTable("Users"));            // table names as in Asset-Management
        builder.Entity<UserRole>(b => b.ToTable("Roles"));
        builder.ApplyConfigurationsFromAssembly(typeof(ApplicationDbContext).Assembly);

        var apply = typeof(ApplicationDbContext).GetMethod(nameof(ApplyTenantFilter),
            BindingFlags.NonPublic | BindingFlags.Instance)!;
        foreach (var type in builder.Model.GetEntityTypes().Select(t => t.ClrType)
                     .Where(typeof(ITenantOwned).IsAssignableFrom))
            apply.MakeGenericMethod(type).Invoke(this, [builder]);
    }

    private void ApplyTenantFilter<T>(ModelBuilder b) where T : class, ITenantOwned =>
        b.Entity<T>().HasQueryFilter(e => e.TenantId == CurrentTenantId).HasIndex(e => e.TenantId);

    public override Task<int> SaveChangesAsync(CancellationToken ct = default)
    {
        foreach (var e in ChangeTracker.Entries<ITenantOwned>())
        {
            if (e.State == EntityState.Added) e.Entity.TenantId = tenant.TenantId;
            else if (e.State == EntityState.Modified && e.Property(x => x.TenantId).IsModified)
                throw new InvalidOperationException("TenantId cannot change.");
        }
        foreach (var e in ChangeTracker.Entries<BaseEntity>())
        {
            if (e.State == EntityState.Added) e.Property(x => x.CreatedAt).CurrentValue = DateTime.UtcNow;
            if (e.State == EntityState.Modified)
            {
                e.Property(x => x.CreatedAt).IsModified = false;   // Asset-Management had "true" here
                e.Property(x => x.UpdatedAt).CurrentValue = DateTime.UtcNow;
            }
        }
        return base.SaveChangesAsync(ct);
    }
}
```

- Register the DbContext **once** (Asset-Management registered it twice), with the audit interceptor:
  `services.AddDbContext<ApplicationDbContext>((sp, o) => o.UseSqlServer(cs).AddInterceptors(sp.GetRequiredService<AuditExecuteUpdateInterceptor>()));`
- Repositories as in Asset-Management (interface in Domain, `AsNoTracking` for reads, `OrderBy` before `Skip`).
  No `IHttpContextAccessor` inside repositories.
- `IgnoreQueryFilters()` only in Infrastructure admin code with a comment; the reviewer flags any other use.
- **Dapper/raw SQL must filter by `TenantId` explicitly** (`WHERE TenantId = @TenantId`) — query filters do
  not apply to it. Parameters only, never string-built SQL.
- Configurations: max length on every string, `HasPrecision(18, 2)` for money, unique indexes include `TenantId`
  (e.g. `HasIndex(x => new { x.TenantId, x.Code }).IsUnique()`).
- Migrations: `dotnet ef migrations add <Name> -p <P>.Infrastructure -s <P>.API`.

## 7. Auth (Identity + JWT)

Keep Asset-Management's `IdentityProvider` and `JwtTokenService` (Infrastructure, implementing `IIdentityProvider`
and `ITokenService` from `Domain/Interfaces`), `JwtSettings`, and `CurrentUserService` (Application, implementing
`ICurrentUserService` and `ITenantContext` from `Domain/Interfaces`), with:

- Claims: `sub`, `email`, `given_name`, `family_name`, `jti`, roles, **[new]** `tenant_id`, **[new]** `security_stamp`.
- **[new] Logout really logs out (REQ-P11):** `logout` calls `UserManager.UpdateSecurityStampAsync(user)`.
  In `AddJwtBearer`, `options.Events.OnTokenValidated` loads the user's current stamp (cache it for ≤ 1 minute
  under `stamp:{userId}`, and remove that key on logout/password change) and calls `context.Fail(...)` when it
  differs from the token's `security_stamp` claim. With several instances and no Redis a revoked token may live
  up to that minute; production uses Redis.
- Lockout stays on (`lockoutOnFailure: true`), but a locked account answers like a wrong password: 401 generic
  (REQ-P02) — Asset-Management returned 403 "locked", which reveals that the email exists.
- `RequireConfirmedEmail = false` until an email provider is configured (ADR); password reset uses
  `IEmailSender` with the body line `Token: <token>` (design §5).
- JWT key only from user-secrets / environment, HS256, at least 64 characters; the app refuses to start
  without it (as in Asset-Management).
- Auth emails (reset, invites) are sent inline with `await`, never fire-and-forget, so they are reliable and testable.

## 8. [new] Rate limiting and security headers

The login limit is per (client IP, email), so it needs the bound request: acquire it in the controller.

```csharp
// Infrastructure DI: one limiter for the app
services.AddSingleton(PartitionedRateLimiter.Create<string, string>(key =>
    RateLimitPartition.GetFixedWindowLimiter(key, _ => new FixedWindowRateLimiterOptions
    {
        PermitLimit = 10, Window = TimeSpan.FromMinutes(1), QueueLimit = 0
    })));

// AuthController.Login (inject PartitionedRateLimiter<string> loginLimiter)
var key = $"{HttpContext.Connection.RemoteIpAddress}|{request.Email.Trim().ToLowerInvariant()}";
using var lease = await loginLimiter.AcquireAsync(key, 1, cancellationToken);
if (!lease.IsAcquired)
    return TooManyRequests("Too many login attempts. Try again in a minute.");  // 429 BaseResponse helper in ApiControllerBase
```

Security headers: a small middleware adding `X-Content-Type-Options: nosniff`, `X-Frame-Options: DENY`,
`Referrer-Policy: strict-origin-when-cross-origin` on every response (HSTS too in Production).

## 9. Cache and background jobs

- Keep Asset-Management's `CacheService` (Polly circuit breaker, Redis optional with memory fallback).
  Cache keys always include the tenant: `dashboard:{tenantId}:total`.
- `BackgroundService`: interval and recipients from configuration (Asset-Management had 15 s and a hard-coded
  address); create a scope per run; jobs that touch tenant data loop over tenants explicitly.

## 10. Tests

```csharp
// <P>.AcceptanceTests  (test-author only; black box over HTTP)
[Collection(AcceptanceCollection.Name)]
public class AuthTests(AppFactory app)
{
    [Fact, Trait("Req", "REQ-P02")]
    public async Task Unknown_email_and_wrong_password_get_the_same_401()
    {
        var client = app.CreateClient();
        var email = $"u{Guid.NewGuid():N}@test.local";            // unique data: tests share one database
        var res = await client.PostAsJsonAsync("/api/auth/login", new { email, password = "Wrong-password-123" });
        Assert.Equal(HttpStatusCode.Unauthorized, res.StatusCode);
    }
}
// Emails (password reset): app.Emails.LastTo(email)!.Body contains "Token: <token>".
```

```ts
// web/e2e/acceptance  (test-author only; accessible names from design.md §6)
test('REQ-P10 new visitor registers and sees the home screen', async ({ page }) => {
  const email = `u${Date.now()}${Math.random().toString(36).slice(2, 8)}@test.local`
  await page.goto('/register')
  await page.getByLabel('First name').fill('Ana')
  await page.getByLabel('Last name').fill('Test')
  await page.getByLabel('Email').fill(email)
  await page.getByLabel('Password').fill('Correct-horse-battery-1')
  await page.getByLabel('Organization name').fill('Acme Ltd')
  await page.getByRole('button', { name: 'Create account' }).click()
  await expect(page.getByRole('heading', { name: 'Acme Ltd' })).toBeVisible()
})
```

- Acceptance test attributes on ONE line — `[Fact, Trait("Req", "REQ-001")]` — because `verify.sh` counts
  declarations per line and fails if fewer tests pass than are declared.
- Unit tests: services with hand-written fakes of the repository interfaces; integration tests: real SQL Server.
- Integration test (yours): every `ITenantOwned` entity in the EF model has a query filter.
- Fixing a bug starts with a failing regression test.
- `npm run e2e:acceptance` runs the locked UI suite; `npm run e2e` runs your own flows.

## 11. Frontend

- `web/src/features/<feature>/`: `XxxPage.tsx`, components, `api.ts` (TanStack Query hooks), tests.
- `web/src/lib/api.ts`: one `fetch` wrapper that adds `Authorization: Bearer`, unwraps `BaseResponse`
  (`data` on success; throws a typed error with `message`/`errors` otherwise) and redirects to `/login` on 401.
- Token: in memory plus `sessionStorage` (survives refresh, not other tabs); never `localStorage`.
- Every input has a `<label>`; loading, empty and error states on every list; works at 360 px.

## 12. Commands

```
docker compose up -d --wait db redis                                  SQL Server + Redis
dotnet user-secrets --project <P>.API set "JwtSettings:Key" "<64+ random chars>"
dotnet user-secrets --project <P>.API set "ConnectionStrings:DefaultConnection" "Server=localhost,1433;Database=<P>;User Id=sa;Password=Local_Dev_Passw0rd!;TrustServerCertificate=True"
dotnet run --project <P>.API --urls http://localhost:5080             API (web dev server proxies /api to it)
dotnet format <P>.slnx --exclude <P>.AcceptanceTests                  never plain dotnet format
cd web && npm run dev | lint | typecheck | test | build | e2e
```
