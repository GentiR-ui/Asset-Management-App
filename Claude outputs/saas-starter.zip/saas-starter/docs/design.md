# Design — <FILL: product name>

> HOW the product is built: the contracts the implementation must follow.
> The acceptance tests are written against sections 5 and 6, so keep them precise.
> Change after approval only together with an ADR in docs/DECISIONS.md.

## 1. Stack (the Asset-Management-App standard)

| Concern | Choice |
|---|---|
| Frontend | React + TypeScript (Vite), TanStack Query, React Router, Tailwind |
| Backend | ASP.NET Core 10, Controllers on `ApiControllerBase` |
| Architecture | `<Product>.Domain`, `.Application`, `.Infrastructure`, `.API` at the repo root. Application → Domain, Infrastructure → Domain, API → Application + Infrastructure |
| Results & errors | `ErrorOr` in services, `<Entity>Errors` classes in Domain, `BaseResponse` envelope on the wire |
| Validation | FluentValidation validators in Application, run by `ValidationFilter` |
| Data | EF Core + SQL Server; repository interfaces in Domain, implementations in Infrastructure; Dapper only for reporting queries |
| Auth | ASP.NET Core Identity + JWT bearer; roles in `AppRoles`; `FallbackPolicy` = authenticated user |
| Multi-tenancy | `TenantId` on every tenant-owned row, EF global query filter, `tenant_id` claim in the JWT |
| Cache | `ICacheService` over `IDistributedCache` (Redis when configured, memory otherwise) with a Polly circuit breaker |
| Background jobs | `BackgroundService`, intervals from configuration — <FILL: none / list jobs> |
| Tests | xUnit (unit, integration, API acceptance) with WebApplicationFactory + Testcontainers SQL Server; Playwright (UI acceptance) |
| Delivery | One Docker image (API + SPA), docker compose (SQL Server + Redis), GitHub Actions |

**Deviations:** none.

## 2. Architecture rules

- **Domain**: entities (`BaseEntity`), enums, `<Entity>Errors`, read models, and every interface that crosses layers: repositories, `ICacheService`, `IEmailSender`, `ITokenService`, `IIdentityProvider`, `ITransactionRunner`, `ICurrentUserService`, `ITenantContext`. No EF, no ASP.NET.
- **Application**: services (`I<Feature>Service` + implementation), request/response DTOs, FluentValidation validators, mapping extension methods (`ToXResponse()`), `CurrentUserService` (implements `ICurrentUserService` and `ITenantContext` from the JWT). Dependencies arrive through the constructor only.
- **Infrastructure**: `ApplicationDbContext`, configurations, migrations, repositories, Identity, JWT, email, `TransactionRunner`.
- **API**: thin controllers (`HandleResult(...)`), filters, `Program.cs`, middleware.
- Each layer registers itself: `AddApplication(configuration)`, `AddInfrastructure(configuration)`.

## 3. Tenancy & authorization

- Registration creates a `Tenant` and an Owner `User` with `TenantId`.
- Every tenant-owned entity implements `ITenantOwned { Guid TenantId }`; `ApplicationDbContext` applies a global query filter and stamps `TenantId` on insert from `ITenantContext` (reads the `tenant_id` claim).
- Another tenant's id therefore returns "not found" (404), never 403.
- Roles (`AppRoles`): `Owner`, `Member` <FILL: adjust to product>. Every controller or action states its roles.
- Logout and password changes rotate the user's security stamp; the JWT carries it and is rejected once it no longer matches.

## 4. Domain model

| Entity | Key fields | Tenant-owned | Notes |
|---|---|---|---|
| Tenant | Id, Name, CreatedAt | — | the organization |
| User | Id, Email, FirstName, LastName, TenantId | (filtered by service, not query filter) | `IdentityUser<Guid>` |
| <FILL> | | | |

## 5. API contracts

All endpoints are under `/api`, JSON, camelCase; enums as strings. Auth header: `Authorization: Bearer <token>`.
Every response is a `BaseResponse`:

```json
{ "success": true, "statusCode": 200, "message": "", "errors": null, "data": { } }
```

Validation errors: 400, `errors` maps each invalid request property to its messages (compare names case-insensitively);
malformed JSON also answers 400 as a `BaseResponse`. Missing or other-tenant ids: 404. Wrong role: 403 and no/invalid
token: 401, both with a `BaseResponse` body. Unknown `/api/...` routes: 404 (401 when unauthenticated).
Only exception to the envelope: `GET /health` answers plain text (`Healthy` / `Unhealthy`).
Rate limits: only login (below). Any further limit must be keyed by email or user, never by IP alone.

### Platform (fixed)

| Method | Path | Auth | Request | Responses | Req |
|---|---|---|---|---|---|
| POST | /api/auth/register | anonymous | `{ firstName, lastName, email, password, organizationName }` | 201 `data: AuthResponse`; 400; 409 email taken | P01, P05 |
| POST | /api/auth/login | anonymous; rate-limited per (client IP, email): 10/min | `{ email, password }` | 200 `data: AuthResponse`; 401 generic (also when locked); 429 | P02, P06 |
| POST | /api/auth/logout | user | — | 200; the token stops working | P11 |
| POST | /api/auth/forgot-password | anonymous | `{ email }` | 200 always; sends an email with subject `Reset your password` whose body has a line `Token: <token>` | P12 |
| POST | /api/auth/reset-password | anonymous | `{ email, token, newPassword }` | 200; 400 invalid/used token | P12 |
| GET | /api/account/me | user | — | 200 `data: MeResponse`; 401 | P03 |
| POST | /api/users | Owner | `{ firstName, lastName, email, password, role }` (role: `Member`) | 201 `data: UserResponse`; 400; 403 Member; 409 | P13, P14 |
| GET | /api/users?page=1&pageSize=20 | Owner | — | 200 `data: PagedResponse<UserResponse>` (own tenant only); 403 Member | P13, P14 |
| GET | /health | anonymous | — | 200 `Healthy`; 503 `Unhealthy` (plain text) | P07 |
| GET | /api/_test/throw | anonymous, **test host only** | — | 500 generic `BaseResponse`; the body must not contain the exception text | P09 |

- `AuthResponse = { userId, email, fullName, token, expiresAtUtc, roles: string[] }`
- `MeResponse = { userId, email, fullName, tenantId, organizationName, roles: string[] }`
- `UserResponse = { id, email, fullName, roles: string[] }`
- `PagedResponse<T> = { items: T[], page, pageSize, totalCount, totalPages }`, `pageSize` 1–100
- `/api/_test/throw` is added by the acceptance/integration `AppFactory` (`TestEndpointsController`, constant
  `TestEndpointsController.SecretDetail` is the exception message); it never exists in the real app.

### Product

| Method | Path | Auth (roles) | Request | Responses | Req |
|---|---|---|---|---|---|
| <FILL> | | | | | |

## 6. UI map

| Route | Purpose | Key elements (accessible names used by tests) | Req |
|---|---|---|---|
| /register | sign up | inputs labelled "First name", "Last name", "Email", "Password", "Organization name"; button "Create account" | P01, P10 |
| /login | sign in | inputs "Email", "Password"; button "Sign in" | P02 |
| / | home (signed in) | heading with the organization name; button "Log out" | P10, P11 |
| <FILL> | | | |

## 7. Integrations

| Service | Purpose | Status |
|---|---|---|
| Email provider (behind `IEmailSender`, `Domain/Interfaces`: `Task SendAsync(string to, string subject, string body, CancellationToken ct = default)`) | password reset, invites | logging sender in Development; real provider before launch. Auth emails are sent inline (awaited) so tests can read them right away |
| Payments (Stripe Checkout + webhooks) | subscriptions | off until a REQ needs it |

## 8. Non-functional notes

- JWT: HS256, `JwtSettings:Key` = at least 64 characters, used as UTF-8 bytes; issuer, audience and lifetime validated.
- Configuration: `appsettings.json` has no secrets; Development uses `dotnet user-secrets`, Production uses environment variables (keys in `.env.example`). The API refuses to start without `JwtSettings:Key`.
- Logging: structured, never passwords, tokens or full request bodies.
- Migrations: EF Core migrations in Infrastructure; applied automatically in Development/Testing, by a deploy step in Production.
